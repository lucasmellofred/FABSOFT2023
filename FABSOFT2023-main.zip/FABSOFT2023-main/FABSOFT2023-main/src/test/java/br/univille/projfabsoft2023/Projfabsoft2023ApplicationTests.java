package br.univille.projfabsoft2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projfabsoft2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
