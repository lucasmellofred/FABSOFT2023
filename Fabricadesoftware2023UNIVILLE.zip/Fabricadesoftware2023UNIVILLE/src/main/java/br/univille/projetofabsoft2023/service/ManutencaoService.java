package br.univille.projetofabsoft2023.service;

import java.util.List;
import br.univille.projetofabsoft2023.entity.Manutencao;

public interface ManutencaoService {

    
}