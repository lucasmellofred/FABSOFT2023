package br.univille.projetofabsoft2023.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.univille.projetofabsoft2023.entity.Manutencao;
@Repository

public interface ManutencaoRepository extends JpaRepository<Manutencao,Long>{
    
}
