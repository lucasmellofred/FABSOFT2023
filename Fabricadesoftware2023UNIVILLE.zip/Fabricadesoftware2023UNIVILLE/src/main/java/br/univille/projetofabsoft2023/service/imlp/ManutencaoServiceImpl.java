package br.univille.projetofabsoft2023.service.imlp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import br.univille.projetofabsoft2023.entity.Manutencao;
import br.univille.projetofabsoft2023.repository.ManutencaoRepository;
import br.univille.projetofabsoft2023.service.ManutencaoService;

public class ManutencaoServiceImpl implements ManutencaoService{
    @Autowired
    private ManutencaoRepository repository;
    
    @Override
    public List<Manutencao> getAll() {
        throw new UnsupportedOperationException("Unimplemented method 'getAll'");
    }
}
