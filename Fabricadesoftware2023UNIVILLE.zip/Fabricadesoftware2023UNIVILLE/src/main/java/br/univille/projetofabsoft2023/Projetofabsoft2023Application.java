package br.univille.projetofabsoft2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetofabsoft2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Projetofabsoft2023Application.class, args);
	}

}
